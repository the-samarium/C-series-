//Function prototypes
void addStudent();
void generateReport(int roll);
char calculateGrade(float avg);