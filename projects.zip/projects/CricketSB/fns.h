void Scorecard();
void updateScore(int run);
void updateWickets();
void Inputs();

extern float oversToPlay;
extern char teamName[50];
extern int run; //indivisul ball score
extern int runs;
extern int wickets;
extern int extras;     
extern int ballsBowled;