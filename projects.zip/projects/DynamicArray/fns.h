#ifndef FNS_H
#define FNS_H

// Function prototypes
int Search(int k, int arr[], int size);
int deleteLast(int arr[], int *size);
int* addLast(int *arr, int *size, int *capacity, int value);
void Display(int arr[], int size);

#endif
